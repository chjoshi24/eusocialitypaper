library(phylolm)
library(phytools)
library(treedata.table)

#For first analysis: Removing eusociality presence for aphids
tree_hap1_pr<-read.nexus("Datafile S1.nexus")
data_hap1_pr<-read.csv("Datafile S3_aphid.csv",header=TRUE,row.names = 1)


#Phylogenetic regression with MPLE model
#Eusociality as a function of haplodiploidy
hap_glm_1a<-phyloglm(Eusociality~Haplodiploidy,data =data_hap1_pr,phy= tree_hap1_pr,method = c("logistic_MPLE"),boot=1000)
summary(hap_glm_1a)
#Haplodiploidy as a function of eusocuality
hap_glm_1b<-phyloglm(Haplodiploidy~Eusociality,data =data_hap1_pr,phy= tree_hap1_pr,method = c("logistic_MPLE"),boot=1000)
summary(hap_glm_1b)


#For second analysis: Removing eusociality presence for aphids and termites
tree_hap2_pr<-read.nexus("Datafile S1.nexus")
data_hap2_pr<-read.csv("Datafile S3_aphid_termite.csv",header=TRUE,row.names = 1)

#Phylogenetic regression with MPLE model
#Eusociality as a function of haplodiploidy
hap_glm_2a<-phyloglm(Eusociality~Haplodiploidy,data =data_hap2_pr,phy= tree_hap2_pr,method = c("logistic_MPLE"),boot=1000)
summary(hap_glm_2a)
#Haplodiploidy as a function of eusocuality
hap_glm_2b<-phyloglm(Haplodiploidy~Eusociality,data =data_hap2_pr,phy= tree_hap2_pr,method = c("logistic_MPLE"),boot=1000)
summary(hap_glm_2b)


#For third analysis: Removing haplodiploidy presence for some of the families
tree_hap3_pr<-read.nexus("Datafile S1.nexus")
data_hap3_pr<-read.csv("Datafile S3_hap_removal.csv",header=TRUE,row.names = 1)

#Phylogenetic regression with MPLE model
#Eusociality as a function of haplodiploidy
hap_glm_3a<-phyloglm(Eusociality~Haplodiploidy,data =data_hap3_pr,phy= tree_hap3_pr,method = c("logistic_MPLE"),boot=1000)
summary(hap_glm_3a)
#Haplodiploidy as a function of eusocuality
hap_glm_3b<-phyloglm(Haplodiploidy~Eusociality,data =data_hap3_pr,phy= tree_hap3_pr,method = c("logistic_MPLE"),boot=1000)
summary(hap_glm_3b)

#Running D.test on the data

#Extracting the hapldoiploidy and eusociality with tips
data_hap1_pr_hap<-setNames(data_hap1_pr[,1],rownames(data_hap1_pr))
data_hap1_pr_eus<-setNames(data_hap1_pr[,2],rownames(data_hap1_pr))

#Making simmaps first
# For unchanged orignal observed data

#simmaps for haplodiploidy
map_hap_ER1<-make.simmap(tree_hap1_pr,data_hap1_pr_hap,model="ER",nsim=10)
map_hap_ARD1<-make.simmap(tree_hap1_pr,data_hap1_pr_hap,model="ARD",nsim=10)

#simmaps for haplodiploidy
map_eus_ER1<-make.simmap(tree_hap1_pr,data_hap1_pr_eus,model="ER",nsim=10)
map_eus_ARD1<-make.simmap(tree_hap1_pr,data_hap1_pr_eus,model="ARD",nsim=10)

#Running D test
dtest_ER1<-Dtest(map_hap_ER1,map_eus_ER1,nsim=10)
dtest_ARD1<-Dtest(map_hap_ARD1,map_eus_ARD1,nsim=10)
